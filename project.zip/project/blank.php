<?php
/**
 * Created by JetBrains PhpStorm.
 * User: dylan
 * Date: 2013-04-10
 * Time: 11:56 AM
 * To change this template use File | Settings | File Templates.
 */
<?php
//Directories
$upload_dir = HOST_WWW_ROOT . "imgs/full/";



//include('../../access.php');
$russel_pattern = "/russel/i";
$basil = "Basil";

$nword = "/niggers?/i";
$upstanding = "fine, upstanding gentlemen";

$gentoo = "/gentoo/i";
$windows = "Microsoft Windows ME";

//CUNT
$cuntword = "/cunt/i";
$bigCunt = "CUNT";

$con = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$index_query = $con->query("SELECT MAX(post_id) FROM post_table");
$index_no = $index_query->fetch_array();
$post_num = $index_no[0] + 1;

if (isset ($_POST['this_post'])) {
    $post = $_POST['this_post'];

    if($post == ""){
        return;
    }


    $post = preg_replace($russel_pattern, $basil, $post);
    $post = preg_replace($nword, $upstanding, $post);
    $post = preg_replace($gentoo, $windows, $post);
    $post = preg_replace($cuntword, $bigCunt, $post);

    $insert_post = "INSERT INTO post_table (post_id, post_data) VALUES ($post_num,\"$post\")";


    $con->query($insert_post);
    if($_FILES['user_img']['error'] > 0) {
        return;
    } else {
        if ($_FILES['user_img']['size'] > 5000000) {
            header('Location: ~/too_large.php');
        }
        $image_name = $_FILES['user_img']['name'];
        $insert_img  = "INSERT INTO images (img_id, img_name) VALUES ($post_num,\"$image_name\")";
        $con->query($insert_img);

        $target = $upload_dir . $image_name;
        move_uploaded_file($_FILES['user_img']['tmp_name'], $target);
    }


    $con->close();
}