<?php
/**
 * User: dylan
 * Date: 2013-04-10
 * Time: 10:15 AM
 */

require("../databaseAccess.php");

// make the connection
$createUserTable = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Ensure it works
if (mysqli_connect_errno($createUserTable)) {
    echo "Failed to connect to the database: " . mysqli_connect_error();
    exit();
}


/*
 * This section will set up the user's personal table
 */
$tableQuery = "CREATE TABLE testTable2 (
                            userID INT(15) PRIMARY KEY NOT NULL,
                            entryID INT (15) NOT NULL,
                            entryName VARCHAR(45) NOT NULL,
                            entryDesc VARCHAR(200),
                            entryType VARCHAR (45),
                            entryDate DATETIME NOT NULL
)";

$tableTEST = "CREATE TABLE testTable2 (
                userID INT(14)
)";

$createUserTable->query($tableQuery);



//$userID = $createUser->query("SELECT userID FROM users WHERE userName LIKE \"$userName\"");

//$createUser->query("INSERT INTO $userNameTable (userID)
//                    VALUES      ($userID)");

$createUserTable->close();

//printf("$userNameTable");