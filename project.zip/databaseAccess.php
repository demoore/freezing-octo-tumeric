<?php
/**
 * User: dylan
 * Date: 2013-04-10
 * Time: 10:02 AM
 */
// Define our constants for the pages
define("DB_HOST", "localhost");
define("DB_USER", "projectUser");
define("DB_PASS", "vR5hZYEqu9ZGRCRW");
define("DB_NAME","project");

/*
 * Just a template
 *
// make the connection
$projectConnection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Ensure it works
if (mysqli_connect_errno($projectConnection)) {
    echo "Failed to connect to the database: " . mysqli_connect_error();
}
*/